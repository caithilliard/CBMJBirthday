UPDATED VERSION — LOCAL M4A

Files to upload to GitHub:
- index.html
- invite.png
- space-cowboy.m4a

Behaviour:
1. Visitor sees TAP TO ENTER.
2. On the click, the page immediately starts the uploaded M4A from 0:00.
3. The invitation animation begins.
4. No YouTube or Spotify is used, so there are no third-party ad noises.
